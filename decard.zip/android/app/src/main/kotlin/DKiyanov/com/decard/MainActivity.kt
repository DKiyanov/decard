package com.dkiyanov.decard

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
