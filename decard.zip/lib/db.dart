import 'dart:convert';
import 'dart:core';
import 'dart:io';

import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

/// исходные файлы
class TabSourceFile {
  static const String tabName         = 'SourceFile';

  static const String kSourceFileId   = 'SourceFileId';
  static const String kFilePath       = 'filePath';
  static const String kChangeDateTime = 'changeDateTime';
  static const String kSize           = 'size';

  static const String createQuery = "CREATE TABLE $tabName ("
      "$kSourceFileId   INTEGER PRIMARY KEY AUTOINCREMENT,"
      "$kFilePath       TEXT,"
      "$kChangeDateTime INTEGER,"
      "$kSize           INTEGER"
      ")";

  static Future<bool> checkFileRegistered(File file) async {
    return checkFileRegisteredEx(file.path, await file.lastModified(), await file.length());
  }

  static Future<bool> checkFileRegisteredEx(String path, DateTime changeDateTime, int size) async {
    final db = await DBProvider.db.database;

    List<Map> maps = await db!.query(tabName,
        columns   : [kSourceFileId],
        where     : '$kFilePath = ? and $kChangeDateTime = ? and $kSize = ?',
        whereArgs : [path, changeDateTime.millisecondsSinceEpoch, size]);

    return maps.isNotEmpty;
  }

  static Future<int> registerFile(File file) async {
    return registerFileEx(file.path, await file.lastModified(), await file.length());
  }

  static Future<int> registerFileEx(String path, DateTime changeDateTime, int size) async {
    final db = await DBProvider.db.database;
    final fileID = await db!.insert(tabName, {
      kFilePath       : path,
      kChangeDateTime : changeDateTime.millisecondsSinceEpoch,
      kSize           : size
    });
    return fileID;
  }

}

/// загруженные json файлы
class TabJsonFile {
  static const String tabName       = 'JsonFile';

  static const String kJsonFileID   = 'jsonFileId';
  static const String kSourceFileID = 'sourceFileID';
  static const String kPath         = 'path';
  static const String kFilename     = 'filename';
  static const String kTitle        = 'title';
  static const String kGuid         = 'GUID';
  static const String kVersion      = 'version';
  static const String kAuthor       = 'author';
  static const String kSite         = 'site';
  static const String kEmail        = 'email';
  static const String kLicense      = 'license';

  static const String createQuery = "CREATE TABLE $tabName ("
      "$kJsonFileID   INTEGER PRIMARY KEY AUTOINCREMENT,"
      "$kSourceFileID INTEGER,"
      "$kPath         TEXT,"
      "$kFilename     TEXT,"
      "$kTitle        TEXT,"
      "$kGuid         TEXT,"
      "$kVersion      INTEGER,"
      "$kAuthor       TEXT,"
      "$kSite         TEXT,"
      "$kEmail        TEXT,"
      "$kLicense      TEXT"
      ")";

  static final Map<String, Object?> _row = {};

  static int     get jsonFileID   => _row[kJsonFileID   ] as int;
  static int     get sourceFileID => _row[kSourceFileID ] as int;
  static String  get path         => _row[kPath         ] as String;
  static String  get filename     => _row[kFilename     ] as String;
  static String  get title        => _row[kTitle        ] as String;
  static String  get guid         => _row[kGuid         ] as String;
  static int     get version      => _row[kVersion      ] as int;
  static String? get author       => _row[kAuthor       ] as String?;
  static String? get site         => _row[kSite         ] as String?;
  static String? get email        => _row[kEmail        ] as String?;
  static String? get license      => _row[kLicense      ] as String?;

  /// возвращает запись файла к указанному guid
  static Future<bool> getRowByGuid(String guid) async {
    final db = await DBProvider.db.database;

    final List<Map<String, Object?>> rows = await db!.query(tabName,
      where     : '$kGuid = ?',
      whereArgs : [guid]
    );

    if (rows.isEmpty) {
      _row.clear();
      return false;
    }

    _row.clear();
    _row.addAll(rows.first);
    return true;
  }

  static setRow(int sourceFileID, String path, String filename, Map jsonMap){
    _row[kSourceFileID] = sourceFileID;
    _row[kPath        ] = path;
    _row[kFilename    ] = filename;
    _row[kTitle       ] = jsonMap[kTitle   ];
    _row[kGuid        ] = jsonMap[kGuid    ];
    _row[kVersion     ] = jsonMap[kVersion ];
    _row[kAuthor      ] = jsonMap[kAuthor  ];
    _row[kSite        ] = jsonMap[kSite    ];
    _row[kEmail       ] = jsonMap[kEmail   ];
    _row[kLicense     ] = jsonMap[kLicense ];
  }

  static Future<void> save() async {
    final db = await DBProvider.db.database;

    if (_row[kJsonFileID] == null){
      _row[kJsonFileID] = await db!.insert(tabName, _row);
    } else {
      final jsonFileID = _row[kJsonFileID ] as int;
      final updateRow = Map<String, dynamic>.from(_row);
      updateRow.remove(kJsonFileID);
      await db!.update(tabName, updateRow,
        where: '$kJsonFileID = ?',
        whereArgs: [jsonFileID]
      );
    }
  }

  static Future<Map<String, dynamic>?> getRow({ required int jsonFileID}) async {
    final db = await DBProvider.db.database;

    final rows = await db!.query(tabName,
        where     : '$kJsonFileID = ?',
        whereArgs : [jsonFileID]
    );

    if (rows.isEmpty) return null;

    final row = rows[0];
    return row;
  }

  static Future<List<Map<String, Object?>>> getAllRows() async {
    final db = await DBProvider.db.database;

    final rows = await db!.query(tabName);
    return rows;
  }
}

class TabCardStyle {
  static const String tabName        = 'CardStyle';

  static const String kID            = 'id';
  static const String kJsonFileID    = 'jsonFileId';
  static const String kCardStyleID   = 'cardStyleId';
  static const String kJson          = 'json';

  static const String createQuery = "CREATE TABLE $tabName ("
      "$kID          INTEGER PRIMARY KEY AUTOINCREMENT,"
      "$kJsonFileID  INTEGER,"
      "$kCardStyleID TEXT,"
      "$kJson        TEXT" // данные стиля хранятся как json, когда понадобится распаковываются
      ")";

  static Future<void> deleteJsonFile(int jsonFileID) async {
    final db = await DBProvider.db.database;
    await db!.delete(tabName, where: '$kJsonFileID = ?', whereArgs: [jsonFileID]);
  }

  static Future<void> insertRow({ required int jsonFileID, required String cardStyleID, required String jsonStr }) async {
    final db = await DBProvider.db.database;

    final Map<String, Object?> row = {
      kJsonFileID  : jsonFileID,
      kCardStyleID : cardStyleID,
      kJson        : jsonStr
    };

    await db!.insert(tabName, row);
  }

  static Future<Map<String, dynamic>?> getRow({ required int jsonFileID, required String cardStyleID }) async {
    final db = await DBProvider.db.database;

    final rows = await db!.query(tabName,
        where     : '$kJsonFileID = ? and $kCardStyleID = ?',
        whereArgs : [jsonFileID, cardStyleID]
    );

    if (rows.isEmpty) return null;

    final row = rows[0];

    final String jsonStr = (row[kJson]) as String;
    final Map<String, dynamic> jsonMap = jsonDecode(jsonStr);

    jsonMap.addEntries(row.entries.where((element) => element.key != kJson));

    // row.forEach((key, value) {
    //   jsonMap[key] = value;
    // });

    return jsonMap;
  }
}

class TabCardHead {
  static const String tabName        = 'CardHead';

  static const String kID            = 'id';
  static const String kJsonFileID    = 'jsonFileId';
  static const String kCardID        = 'cardId';
  static const String kTitle         = 'title';
  static const String kBodyCount     = 'bodyCount';

  static const String createQuery = "CREATE TABLE $tabName ("
      "$kID          INTEGER PRIMARY KEY AUTOINCREMENT,"
      "$kJsonFileID  INTEGER,"
      "$kCardID      TEXT,"  // идентификатор карточки из json файла
      "$kTitle       TEXT,"
      "$kBodyCount   INTEGER"
      ")";

  static Future<void> deleteJsonFile(int jsonFileID) async {
    final db = await DBProvider.db.database;
    await db!.delete(tabName, where: '$kJsonFileID = ?', whereArgs: [jsonFileID]);
  }

  static Future<void> insertRow({ required int jsonFileID, required String cardID, required String title, required int bodyCount }) async {
    final db = await DBProvider.db.database;

    final Map<String, Object?> row = {
      kJsonFileID : jsonFileID,
      kCardID     : cardID,
      kTitle      : title,
      kBodyCount  : bodyCount
    };

    await db!.insert(tabName, row);
  }

  static Future<Map<String, dynamic>?> getRow({ required int jsonFileID, required String cardID }) async {
    final db = await DBProvider.db.database;

    final rows = await db!.query(tabName,
        where     : '$kJsonFileID = ? and $kCardID = ?',
        whereArgs : [jsonFileID, cardID]
    );

    if (rows.isEmpty) return null;

    final row = rows[0];

    final Map<String, dynamic> jsonMap = {};

    row.forEach((key, value) {
      jsonMap[key] = value;
    });

    return jsonMap;
  }
}

class TabCardLink {
  static const String tabName         = 'CardLink';

  static const String kID             = 'id';
  static const String kJsonFileID     = 'jsonFileId';
  static const String kCardID         = 'cardId';
  static const String kParentCardID   = 'parentCardId';
  static const String kConnectionType = 'connectionType';

  static const String createQuery = "CREATE TABLE $tabName ("
      "$kID             INTEGER PRIMARY KEY AUTOINCREMENT,"
      "$kJsonFileID     INTEGER,"
      "$kCardID         TEXT,"
      "$kParentCardID   TEXT,"
      "$kConnectionType TEXT"
      ")";

  static Future<void> deleteJsonFile(int jsonFileID) async {
    final db = await DBProvider.db.database;
    await db!.delete(tabName, where: '$kJsonFileID = ?', whereArgs: [jsonFileID]);
  }

  static Future<void> insertRow({ required int jsonFileID, required String cardID, required String parentCardId, required String connectionType }) async {
    final db = await DBProvider.db.database;

    final Map<String, Object?> row = {
      kJsonFileID     : jsonFileID,
      kCardID         : cardID,
      kParentCardID   : parentCardId,
      kConnectionType : connectionType
    };

    await db!.insert(tabName, row);
  }
}

class TabCardBody{
  static const String tabName     = 'CardBody';

  static const String kID         = 'id';
  static const String kJsonFileID = 'jsonFileId';
  static const String kCardID     = 'cardId';
  static const String kBodyNum    = 'bodyNum';
  static const String kJson       = 'json';

  static const String createQuery = "CREATE TABLE $tabName ("
      "$kID         INTEGER PRIMARY KEY AUTOINCREMENT,"
      "$kJsonFileID INTEGER,"
      "$kCardID     TEXT,"    // идентификатор карточки из json файла
      "$kBodyNum    INTEGER," // у карточки может быть много тел, здесь хранится номер тела
      "$kJson       TEXT"     // данные тела карточки хранятся как json, когда понадобится распаковываются
      ")";

  static Future<void> deleteJsonFile(int jsonFileID) async {
    final db = await DBProvider.db.database;
    await db!.delete(tabName, where: '$kJsonFileID = ?', whereArgs: [jsonFileID]);
  }

  static Future<void> insertRow({ required int jsonFileID, required String cardID, required int bodyNum, required String json }) async {
    final db = await DBProvider.db.database;

    final Map<String, Object?> row = {
      kJsonFileID : jsonFileID,
      kCardID     : cardID,
      kBodyNum    : bodyNum,
      kJson       : json
    };

    await db!.insert(tabName, row);
  }

  static Future<Map<String, dynamic>?> getRow({ required int jsonFileID, required String cardID, required int bodyNum }) async {
    final db = await DBProvider.db.database;

    final rows = await db!.query(tabName,
        where     : '$kJsonFileID = ? and $kCardID = ? and $kBodyNum = ?',
        whereArgs : [jsonFileID, cardID, bodyNum]
    );

    if (rows.isEmpty) return null;

    final row = rows[0];

    final String jsonStr = (row[kJson]) as String;
    final Map<String, dynamic> jsonMap = jsonDecode(jsonStr);

    row.forEach((key, value) {
      jsonMap[key] = value;
    });

    return jsonMap;
  }
}

class DayResult {
  DayResult({
    required this.day,
    this.countTotal = 0,
    this.countOk    = 0
  });

  final int day;
  int countTotal;
  int countOk;

  void addResult(bool resultOk){
    countTotal ++;
    if (resultOk) countOk ++;
  }

  factory DayResult.fromJson(Map<String, dynamic> json) => DayResult(
    day        : json["day"],
    countTotal : json["countTotal"],
    countOk    : json["countOk"],
  );

  Map<String, dynamic> toJson() => {
    "day"        : day,
    "countTotal" : countTotal,
    "countOk"    : countOk,
  };
}


class TabCardStat{
  static const String tabName          = 'CardStat';

  static const String kID              = 'id';
  static const String kJsonFileID      = 'jsonFileId';
  static const String kCardID          = 'cardId';
  static const String kQuality         = 'quality';
  static const String kQualityFromDate = 'qualityFromDate';
  static const String kStartDate       = 'startDate';
  static const String kLastTestDate    = 'lastTestDate';
  static const String kTestsCount      = 'testsCount';
  static const String kJson            = 'json';

  static const String createQuery = "CREATE TABLE $tabName ("
      "$kID              INTEGER PRIMARY KEY AUTOINCREMENT,"
      "$kJsonFileID      INTEGER,"
      "$kCardID          TEXT,"    // идентификатор карточки из json файла
      "$kQuality         INTEGER," // качество изучения, 1 - картичка полностью изучена; 100 - минимальная степень изученности.
      "$kQualityFromDate INTEGER," // первая дата учтённая при расчёте quality
      "$kStartDate       INTEGER," // дата начала изучения
      "$kLastTestDate    INTEGER," // дата последнего изучения
      "$kTestsCount      INTEGER," // количество предъявления
      "$kJson            TEXT"     // данные статистики карточки хранятся как json, когда понадобится распаковываются используются для расчёта quality и обновляются
      ")";

  /// удаляет карточки которых нет в списке
  static Future<void> removeOldCard(int jsonFileID, List<String> cardIdList) async {
    final db = await DBProvider.db.database;

    final rows = await db!.query(tabName,
      columns   : [kCardID],
      where     : '$kJsonFileID = ?',
      whereArgs : [jsonFileID]
    );

    for (var row in rows) {
      final String cardID = row[kCardID] as String;
      if (!cardIdList.contains(cardID)){
        db.delete(tabName,
          where     : '$kJsonFileID = ? and $kCardID = ?',
          whereArgs : [jsonFileID, cardID]
        );
      }
    }
  }

  static List<DayResult> dayResultsFromJson( String jsonStr){
    if (jsonStr.isEmpty){
      return [];
    }

    final jsonMap = jsonDecode(jsonStr);
    return List<DayResult>.from(jsonMap.map((x) => DayResult.fromJson(x)));
  }

  static String dayResultsToJson(List<DayResult> dayResults) {
    final jsonMap = List<dynamic>.from(dayResults.map((x) => x.toJson()));
    return jsonEncode(jsonMap);
  }

  static Future<Map<String, dynamic>?> getRow({ required int jsonFileID, required String cardID }) async {
    final db = await DBProvider.db.database;

    final rows = await db!.query(tabName,
        where     : '$kJsonFileID = ? and $kCardID = ?',
        whereArgs : [jsonFileID, cardID]
    );

    if (rows.isEmpty) return null;

    final row = rows[0];
    return row;
  }
}

class DBProvider {
  DBProvider._();

  static final DBProvider db = DBProvider._();

  Database? _database;

  Future<Database?> get database async {
    if (_database != null) return _database;
    _database = await _initDB();
    return _database;
  }

   Future<Database> _initDB() async {
    Directory documentsDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentsDirectory.path, "decard.db");
    print('DB path: $path');
    return await openDatabase(path, version: 1, onOpen: (db) {},
        onCreate: (Database db, int version) async {
          await _createTables(db);
        });
  }

  _createTables(Database db) async {
    await db.execute(TabSourceFile.createQuery);
    await db.execute(TabJsonFile.createQuery);
    await db.execute(TabCardStyle.createQuery);
    await db.execute(TabCardHead.createQuery);
    await db.execute(TabCardLink.createQuery);
    await db.execute(TabCardBody.createQuery);
    await db.execute(TabCardStat.createQuery);
  }

  deleteDB( ) async {
    if (_database == null) return;
    deleteDatabase(_database!.path);
  }
}