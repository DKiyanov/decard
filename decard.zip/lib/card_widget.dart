import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:path/path.dart' as path_util;

import 'audio_widget.dart';
import 'card_model.dart';
import 'common.dart';

final _random = Random();

class CardWidget extends StatefulWidget {
  final CardData card;
  final VoidCallback onPressSelectNextCard;

  const CardWidget({required this.card, required this.onPressSelectNextCard, Key? key}) : super(key: key);

  @override
  State<CardWidget> createState() => _CardWidgetState();
}

class _CardWidgetState extends State<CardWidget> {
  int       _cardHashCode = 0;

  int       _tryCount = 0;
  bool?     _result;

  final     _answerVariantList = <String>[]; // список вариантов ответов
  final     _selValues = <String>[]; // Выбранные значения

  int       _costDuration = 0; // длительность в мимлисекундах
  double    _costValue = 0; // заработанное
  double    _timeProgress = 0; // процент потраченого времени
  Timer?    _costTimer;
  DateTime? _startTime;
  final     _inputController = TextEditingController(); // Для полей ввода
  String    _widgetKeyboardText = '';

  void _prepareAnswerVariantList() {
    // списку из body отдаётся предпочтение
    _answerVariantList.clear();
    _answerVariantList.addAll(widget.card.style.answerVariantList);

    // выдёргиваем из списка лишние варианты так чтоб полчился список нужного размера
    if (widget.card.style.answerVariantCount > widget.card.body.answerList.length && _answerVariantList.length > widget.card.style.answerVariantCount){
      while (_answerVariantList.length > widget.card.style.answerVariantCount) {
        final rndIndex = _random.nextInt(_answerVariantList.length);
        final variant = _answerVariantList[rndIndex];
        if (!widget.card.body.answerList.contains(variant)) {
          _answerVariantList.removeAt(rndIndex);
        }
      }
    }

    if (widget.card.style.answerVariantListRandomize) {
      // перемешиваем список в случайном порядке
      _answerVariantList.shuffle(_random);
    }
  }

  // Проверяет что карточка изменилась и подготавливает начальное состояние для
  // просмотра новой карточки
  // вызывается из build в самом начале
  // решает следущую проблему:
  // cardController установил карточку и вызвал notifyListeners()
  // ChangeNotifierProvider увидел изменение и вызвал перисовку ... Consumer
  // вызвался метод _CardWidgetState.build
  // внешнее состояние на данный момент изменённое,
  // а вот внутренне состояние (_CardWidgetState) ещё не знает об изменениях
  // метод _cardChangeCheckAndPrepare проверяет наличие изменения
  // и если оно есть подготавливает внутренне состояние виджета
  void _cardChangeCheckAndPrepare(){
    if (_cardHashCode == widget.card.hashCode) return;

    _cardHashCode = widget.card.hashCode;
    _clearState();
    _startDisplayCard();
  }

  void _onMultiSelectAnswer() {
    int answerCount = 0;
    for (var value in _selValues) {
      if (!widget.card.body.answerList.contains(value)) {
        _onAnswer(false);
        return;
      }
      answerCount ++;
    }

    if (widget.card.body.answerList.length != answerCount) {
      _onAnswer(false);
      return;
    }

    _onAnswer(true);
  }

  void _onSelectAnswer(String answerValue) {
    _selValues.clear();
    _selValues.add(answerValue);
    final tryResult = widget.card.body.answerList.contains(answerValue);
    _onAnswer(tryResult);
  }

  void _onAnswer(bool tryResult) {
    _stopCostTimer();

    if (tryResult) {
      widget.card.setResult(true, _costValue);

      setState(() {
        _result = true;
      });
      return;
    }

    _tryCount ++;

    if (_tryCount < widget.card.tryCount) {
      Fluttertoast.showToast(msg: TextConst.txtInvalidAnswer);
      return;
    }

    widget.card.setResult(false, - widget.card.penalty.toDouble());

    setState(() {
      _result = false;
    });
  }

  void _stopCostTimer(){
    if (_costTimer != null) {
      _costTimer!.cancel();
      _costTimer = null;
    }
  }

  void _clearState() {
    _tryCount = 0;
    _result = null;
    _answerVariantList.clear();
    _selValues.clear();

    _startTime = null;
    _costValue = 0;
    _costDuration = 0;
    _timeProgress = 0;
    _inputController.text = '';
    _widgetKeyboardText = '';

    _stopCostTimer();
  }

  void _startDisplayCard() {
    _startTime = DateTime.now();
    _costValue = widget.card.cost.toDouble();
    _costDuration = widget.card.duration * 1000;
    _prepareAnswerVariantList();
    _initCostTimer();
  }

  void _initCostTimer() {
    _stopCostTimer();

    if (widget.card.duration == 0 || widget.card.cost == widget.card.lowCost) return;

    _costTimer = Timer.periodic( const Duration(milliseconds: 100), (timer){
      setState(() {
        final time = DateTime.now().difference(_startTime!).inMilliseconds;

        if (time >= _costDuration) {
          _costValue = widget.card.lowCost.toDouble();
          _timeProgress = 1;
          timer.cancel();
          return;
        }

        _costValue = widget.card.cost - ( (widget.card.cost - widget.card.lowCost) * time ) / _costDuration;
        _timeProgress = time / _costDuration;
      });
    });
  }

  /// панель отображающая стоимость решения карточки, штраф за не верной решение
  /// анимация изменения стоимости от задержки при решении
  Widget _getCostPanel() {
    String panelTxt = '';

    if (_result == null) {
      panelTxt = TextConst.txtCost;
    } else {
      if (_result!){
        panelTxt = TextConst.txtEarned;
      } else {
        panelTxt = TextConst.txtPenalty;
      }
    }

    return Container(
      color: Theme.of(context).primaryColorDark,
      child: Padding(
        padding: const EdgeInsets.all(4.0),
        child: Row(
          children: [
            Text(panelTxt),
            Container(width: 4),
            Expanded(child: _getCostPanelEx()),
          ],
        ),
      ),
    );
  }

  Widget _getCostPanelEx() {
    if (_result != null) {
      if (_result!) {
        return Row(children: [ _costBox(_costValue, Colors.lightGreen) ]);
      } else {
        if (widget.card.penalty != 0) {
          return Row(children: [ _costBox( - widget.card.penalty, Colors.deepOrangeAccent) ]);
        } else {
          return Row(children: [ _costBox(0, Colors.yellow) ]);
        }
      }
    }

    if (_costTimer != null) {
      return Row(children: [
        _costBox(widget.card.cost, Colors.green),
        Container(width: 4),
        Expanded(child: Stack(
            alignment: Alignment.center,
            children: [
              ClipRRect(
                borderRadius: const BorderRadius.all(Radius.circular(10)),
                child: LinearProgressIndicator(
                  backgroundColor: Colors.green,
                  valueColor: const AlwaysStoppedAnimation<Color>(Colors.lightGreen),
                  value: _timeProgress,
                  minHeight: 18,
                ),
              ),
              Text(_costValue.toStringAsFixed(1)),
            ]
        )),
        Container(width: 4),
        _costBox(widget.card.lowCost, Colors.lightGreen),
        Container(width: 4),
        _costBox(widget.card.penalty, Colors.deepOrangeAccent),
      ]);
    }

    return Row(children: [
      _costBox(widget.card.cost, Colors.lightGreen),
      if (widget.card.penalty != 0) ...[
        Expanded(child: Container()),
        _costBox( - widget.card.penalty, Colors.deepOrangeAccent),
      ]
    ]);
  }

  Widget _costBox(cost, Color color) {
    String costStr = '';

    if (cost is int) {
      costStr = '$cost';
    }
    if (cost is double) {
      costStr = cost.toStringAsFixed(1);
    }

    if (costStr.length <= 2) {
      return Container(
        width: 25,
        height: 25,
        decoration: BoxDecoration(
          color: color,
          border: Border.all(
            color: color,
          ),
          shape: BoxShape.circle,
//            borderRadius: const BorderRadius.all(Radius.circular(20))
        ),
        child: Align(child: Text(costStr)),
      );
    }

    return Container(
      padding: const EdgeInsets.all(5.0),
      decoration: BoxDecoration(
          color: color,
          border: Border.all(
            color: color,
          ),
          borderRadius: const BorderRadius.all(Radius.circular(20))
      ),
      child: Text(costStr),
    );
  }

  @override
  Widget build(BuildContext context) {
    _cardChangeCheckAndPrepare();

    final widgetList = <Widget>[];

    if (widget.card.body.questionData.image != null) {
      final urlType = getUrlType(widget.card.body.questionData.image!);

      if ( urlType == UrlType.httpUrl ) {
        widgetList.add(
          Image.network(widget.card.body.questionData.image!)
        );
      }

      if ( urlType == UrlType.localPath ) {
        final absPath = path_util.normalize( path_util.join(widget.card.pacInfo.path, widget.card.body.questionData.image) );
        final imgFile = File(absPath);
        if (imgFile.existsSync()) {
          widgetList.add(
              Image.file( imgFile )
          );
        }
      }
    }

    if (widget.card.body.questionData.audio != null) {
      final urlType = getUrlType(widget.card.body.questionData.audio!);

      if ( urlType == UrlType.httpUrl ) {
        widgetList.add(
            AudioPanelWidget(httpUrl : widget.card.body.questionData.audio!)
        );
      }

      if ( urlType == UrlType.localPath ) {
        final absPath = path_util.normalize( path_util.join(widget.card.pacInfo.path, widget.card.body.questionData.audio) );
        final imgFile = File(absPath);
        if (imgFile.existsSync()) {
          widgetList.add(
              AudioPanelWidget(localFilePath : absPath)
          );
        }
      }
    }

    if (widget.card.body.questionData.text != null) {
      widgetList.add(
        AutoSizeText(
          widget.card.body.questionData.text!,
          style: const TextStyle(fontSize: 30),
          textAlign: TextAlign.center,
        ),
      );
    }

    if (_result != null) {
      for (var value in _answerVariantList) {
        if (_selValues.contains(value)){
          widgetList.add(
              ElevatedButton(
                style: ElevatedButton.styleFrom(alignment: _getAnswerAlignment()),
                child: Text(value),
                onPressed: (){},
              )
          );
        }
      }

      if (_result!){
        widgetList.add(
            Container(
                decoration: const BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(15)),
                    color: Colors.lightGreenAccent
                ),
                child: Padding(
                  padding: const EdgeInsets.all(4.0),
                  child: Text(
                      TextConst.txtRightAnswer,
                      textAlign: widget.card.style.answerVariantAlign
                  ),
                )
            )
        );
      } else {
        widgetList.add(
            Container(
                decoration: const BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(15)),
                  color: Colors.deepOrange
                ),
                child: Padding(
                  padding: const EdgeInsets.all(4.0),
                  child: Text(
                      TextConst.txtInvalidAnswer,
                      textAlign: widget.card.style.answerVariantAlign
                  ),
                )
            )
        );

        if (!widget.card.style.dontShowAnswer) {
          widgetList.add( Text( '${TextConst.txtRightAnswerIs} ${widget.card.body.answerList.join("; ")}' ) );
        }
      }
    }

    if (_result == null) {
      _addAnswerVariants(widgetList);
    }

    return Column(children: [
      _getCostPanel(),

      Expanded( child: Padding(
        padding: const EdgeInsets.fromLTRB(8, 8, 8, 4),
        child:  Stack(
          children: [
            ListView(
              children: widgetList,
            ),
            if (widget.card.style.answerVariantMultiSel && _result == null) ...[
              Align(
                alignment: Alignment.bottomRight,
                child: ElevatedButton(
                  onPressed: _onMultiSelectAnswer,
                  style: ElevatedButton.styleFrom(
                      shape: const CircleBorder(),
                      padding: const EdgeInsets.all(17),
                      backgroundColor: Colors.green
                  ),
                  child: const Icon(Icons.check, color: Colors.white),
                )
              )
            ]
          ],
        )
      )),

      if (_result != null) ...[
        Row(
          children: [
            Expanded(child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: ElevatedButton(onPressed: widget.onPressSelectNextCard, child: Text(TextConst.txtSetNextCard)),
            )),
          ],
        ),
      ]

    ]);
  }

  Alignment _getAnswerAlignment() {
    var alignment = Alignment.center;

    switch(widget.card.style.answerVariantAlign) {
      case TextAlign.left:
        alignment = Alignment.centerLeft;
        break;
      case TextAlign.right:
        alignment = Alignment.centerRight;
        break;
      default:
        alignment = Alignment.center;
    }

    return alignment;
  }

  void _addAnswerVariants(List<Widget> widgetList) {
    Widget? answerInput;

    final alignment = _getAnswerAlignment();

    final answerInputMode = widget.card.style.answerInputMode;
//    const answerInputMode = AnswerInputMode.widgetKeyboard; // for debug

    // Поле ввода
    if ( answerInputMode == AnswerInputMode.input    ||
         answerInputMode == AnswerInputMode.inputDigit
    ) {
      var keyboardMode = TextInputType.text;

      if (answerInputMode == AnswerInputMode.inputDigit) {
        keyboardMode = TextInputType.number;
      }

      answerInput = Padding(
        padding: const EdgeInsets.only(top: 4),
        child: TextField(
          controller: _inputController,
          textAlign: widget.card.style.answerVariantAlign,
          keyboardType: keyboardMode,
          decoration: InputDecoration(
            filled: true,
            enabledBorder: OutlineInputBorder(
              borderSide: const BorderSide(width: 3, color: Colors.blueGrey),
              borderRadius: BorderRadius.circular(15),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: const BorderSide(width: 3, color: Colors.blue),
              borderRadius: BorderRadius.circular(15),
            ),
            suffixIcon : IconButton(
              icon: const Icon(Icons.check, color: Colors.lightGreen),
              onPressed: ()=> _onSelectAnswer(_inputController.text),
            ),
          ),
        ),
      );
    }

    // Выпадающий список
    if (answerInputMode == AnswerInputMode.ddList) {
      answerInput = Padding(
        padding: const EdgeInsets.only(top: 4),
        child: TextField(
          controller: _inputController,
          readOnly: true,
          textAlign: widget.card.style.answerVariantAlign,
          decoration: InputDecoration(
            filled: true,
            enabledBorder: OutlineInputBorder(
              borderSide: const BorderSide(width: 3, color: Colors.blueGrey),
              borderRadius: BorderRadius.circular(15),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: const BorderSide(width: 3, color: Colors.blue),
              borderRadius: BorderRadius.circular(15),
            ),
            suffixIcon : Row( mainAxisSize: MainAxisSize.min, children: [
              PopupMenuButton<String>(
                icon: const Icon(Icons.arrow_drop_down_outlined),
                itemBuilder: (context) {
                  return _answerVariantList.map<PopupMenuItem<String>>((value) => PopupMenuItem<String>(
                    value: value,
                    child: Text(value),
                  )).toList();
                },
                onSelected: (value){
                  setState(() {
                    _inputController.text = value;
                  });
                },
              ),

              IconButton(
                icon: const Icon(Icons.check, color: Colors.lightGreen),
                onPressed: ()=> _onSelectAnswer(_inputController.text),
              )
            ]),
          ),
        ),
      );
    }

    // Кнопки в строку
    if (answerInputMode == AnswerInputMode.hList) {
      answerInput = Align( child: Wrap(
        alignment: WrapAlignment.center,
        spacing: 4,
        children: _answerVariantList.map<Widget>((itemStr) {
          return _getButton(itemStr, alignment);
        }).toList(),
      ));
    }

    // Кнопки в столбец
    if (answerInputMode == AnswerInputMode.vList) {
      answerInput = ListView(
        shrinkWrap: true,
        children: _answerVariantList.map<Widget>((itemStr) {
          return _getButton(itemStr, alignment);
        }).toList(),
      );
    }

    // Виртуальная клавиатура
    if (answerInputMode == AnswerInputMode.widgetKeyboard) {
      final keyStr = widget.card.style.widgetKeyboard!;
//      const keyStr = '1\t2\t3\n4\t5\t6\n7\t8\t9\n0';
      answerInput = _widgetKeyboard(keyStr);
    }

    if (answerInput != null) widgetList.add( answerInput );
  }

  Widget _getButton(String value, AlignmentGeometry alignment){
    if (widget.card.style.answerVariantMultiSel) {
      if ( _selValues.contains(value) ) {

        return ElevatedButton(
          style: ElevatedButton.styleFrom(alignment: alignment, backgroundColor: Colors.amberAccent),
          child: Text(value),
          onPressed: () {
            setState(() {
              _selValues.remove(value);
            });
          },
        );

      } else {

        return ElevatedButton(
          style: ButtonStyle(alignment: alignment),
          child: Text(value),
          onPressed: () {
            setState(() {
              _selValues.add(value);
            });
          },
        );

      }
    }

    return ElevatedButton(
      style: ButtonStyle(alignment: alignment),
      child: Text(value),
      onPressed: () => _onSelectAnswer(value),
    );
  }

  Widget _widgetKeyboard(String keyStr){
    final rowList = keyStr.split('\n');
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 4, bottom: 4),
          child: Container(
            decoration: BoxDecoration(
                border: Border.all(
                  color: Colors.blue,
                  width: 2,
                ),
                borderRadius: const BorderRadius.all(Radius.circular(10))
            ),

            child:  Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.clear, color: Colors.black),
                  onPressed: (){
                    setState(() {
                      _widgetKeyboardText = "";
                    });
                  },
                ),

                IconButton(
                  icon: const Icon(Icons.backspace_outlined, color: Colors.black),
                  onPressed: (){
                    if (_widgetKeyboardText.isEmpty) return;
                    setState(() {
                      _widgetKeyboardText = _widgetKeyboardText.substring(0, _widgetKeyboardText.length - 1);
                    });
                  },
                ),

                Expanded(
                  child: Container(
                    color: Colors.black12,
                    child: Padding(
                      padding: const EdgeInsets.only(left: 4, right: 4),
                      child: AutoSizeText(
                        _widgetKeyboardText,
                        style: const TextStyle(fontSize: 30, color: Colors.blue),
//                  textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                ),

                IconButton(
                  icon: const Icon(Icons.check, color: Colors.lightGreen),
                  onPressed: ()=> _onSelectAnswer(_widgetKeyboardText),
                )
              ],
            )
          ),
        ),

        ListView(
          shrinkWrap: true,
          children: rowList.map((row) {
            return Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: row.split('\t').map((key) => Padding(
                padding: const EdgeInsets.only(left: 5, right: 5),
                child: ElevatedButton(
                  onPressed: () {
                    setState(() {
                      _widgetKeyboardText += key;
                    });
                  },
                  child: Text(key.trim()) ),
              )
              ).toList());
          }).toList()

        ),
      ],
    );
  }
}




