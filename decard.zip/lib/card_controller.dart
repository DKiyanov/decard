import 'dart:math';
import 'package:collection/collection.dart';
import 'package:decard/app_state.dart';

import 'package:sqflite/sqflite.dart';

import 'dk_event.dart';
import 'common.dart';
import 'db.dart';
import 'card_model.dart';


final _random = Random();

enum CardSetBody {
  none,
  first,
  last,
  random,
}

class CardController {
  static final CardController _instance = CardController._();

  factory CardController() {
    return _instance;
  }

  CardController._();

  PacInfo?   _pacInfo;
  CardHead?  _cardHead;
  CardBody?  _cardBody;
  CardStyle? _cardStyle;
  CardStat?  _cardStat;

  CardData? _card;
  CardData? get card => _card;

  final onChange = SimpleEvent();

  /// Устанавливает данные текущей карточки
  Future<void> setCardID(int jsonFileID, String cardID, {int? bodyNum, CardSetBody setBody = CardSetBody.random}) async {
    await ProcessCardController.instance.init();

    _pacInfo   = null;
    _cardHead  = null;
    _cardBody  = null;
    _cardStyle = null;
    _cardStat  = null;

    final headData = await TabCardHead.getRow(jsonFileID: jsonFileID, cardID: cardID);
    _cardHead = CardHead.fromMap(headData!);

    if (bodyNum != null) {
      await _setBodyNum(bodyNum);
    } else {
      switch(setBody){
        case  CardSetBody.first:
          await _setBodyNum(0);
          break;
        case CardSetBody.last:
          await _setBodyNum(_cardHead!.bodyCount - 1);
          break;
        case CardSetBody.random:
          await _setRandomBodyNum();
          break;
        case CardSetBody.none:
          break;
      }
    }

    final statData = await ProcessCardController.instance.getStatData(jsonFileID: jsonFileID, cardID: cardID);
    _cardStat = CardStat.fromMap(statData!);

    final pacData = await TabJsonFile.getRow(jsonFileID: jsonFileID);
    _pacInfo = PacInfo.fromMap(pacData!);

    _card = CardData(head : _cardHead!, body: _cardBody!, style: _cardStyle!, stat: _cardStat!, pacInfo : _pacInfo!, onResult: _onCardResult );

    onChange.send();
  }

  /// Устанавливает заданное тело в текущей карточке
  Future<void> setBodyNum(int bodyNum) async {
    await _setBodyNum(bodyNum);
    _card!.body  = _cardBody!;
    _card!.style = _cardStyle!;
    onChange.send();
  }

  Future<void> _setBodyNum(int bodyNum) async {
    final bodyData = await TabCardBody.getRow(jsonFileID: _cardHead!.jsonFileId, cardID: _cardHead!.cardID, bodyNum: bodyNum );
    _cardBody = CardBody.fromMap(bodyData!);

    final Map<String, dynamic> styleMap = {};
    for (var styleID in _cardBody!.styleIdList) {
      final styleData = await TabCardStyle.getRow(jsonFileID: _cardHead!.jsonFileId, cardStyleID: styleID );
      styleMap.addEntries(styleData!.entries.where((element) => element.value != null));
    }

    styleMap.addEntries(_cardBody!.styleMap.entries.where((element) => element.value != null));

    _cardStyle = CardStyle.fromMap(styleMap);
  }

  Future<void> _setRandomBodyNum() async {
    int bodyNum = 0;
    if (_cardHead!.bodyCount > 1) bodyNum = _random.nextInt(_cardHead!.bodyCount);

    await _setBodyNum(bodyNum);
  }

  Future<bool> selectNextCard() async {
    await ProcessCardController.instance.init();

    CardID? newCard;

    for (int i = 0; i < 10; i++) { // чтоб повторно не выдавалась последняя выданная карточка
      newCard = await ProcessCardController.instance.getCardForTest();
      if (newCard == null) return false;

      if (card?.head.cardID != newCard.cardID || card?.head.jsonFileId != newCard.jsonFileId){
        break;
      }
    }

    if (newCard == null) return false;
    await setCardID( newCard.jsonFileId, newCard.cardID );

    return true;
  }

  void _onCardResult(bool result, double earn){
    ProcessCardController.instance.registerResult(_cardHead!.jsonFileId, _cardHead!.cardID, result);
    appState.addEarn(earn);
  }
}

class _CardStat {
  final int id;
  int quality;

  _CardStat({ required this.id, required this.quality });

  factory _CardStat.fromMap(Map<String, dynamic> json) {
    return _CardStat(
      id      : json["id"],
      quality : json["quality"],
    );
  }
}

/// Обеспечивает анализ статистики для выбора карточки
class ProcessCardController {
  ProcessCardController._();

  static final ProcessCardController instance = ProcessCardController._();

  // quality :  1 - картичка полностью изучена; minimalQuality - минимальная степень изученности.
  static const int hotCardQualityLimit = 20;  // 1 - 20 Карточка хорошо изучена; 21 - minimalQuality Карточка в активном изучении
  static const int hotCountLimit       = 8;   // Предельное кол-во карточек в активном изучении
  static const int hotDayCount         = 7;   // Количество дней для которых расчитывается стстистика
  static const int minimalQuality      = 100; // Минимальное качество изучения

  bool _initialized = false;
  late Database db;
  final cardStatList = <_CardStat>[];

  /// инциализация/подготовка
  Future<void> init() async {
    if (_initialized) return;

    db = (await DBProvider.db.database)!;
    await _loadCardStat();

    _initialized = true;
  }

  /// Загрузка статистики из БД
  Future<void> _loadCardStat() async {
    final rows = await db.query(TabCardStat.tabName,
      columns   : [TabCardStat.kID, TabCardStat.kQuality],
      orderBy   : TabCardStat.kID,
    );

    cardStatList.clear();
    cardStatList.addAll(rows.map((row) => _CardStat.fromMap(row)));
  }

  Future<CardID> _getCardIdFromStatID(int statID) async {
    final rows = await db.query(TabCardStat.tabName,
      columns   : [TabCardStat.kJsonFileID, TabCardStat.kCardID],
      where     : '${TabCardStat.kID} = ?',
      whereArgs : [statID],
    );

    final row = rows[0];

    final jsonFileId = row[TabCardStat.kJsonFileID] as int;
    final cardID     = row[TabCardStat.kCardID] as String;
    return CardID(jsonFileId, cardID);
  }

  /// Выбирает карточку для тестирования
  Future<CardID?> getCardForTest() async {
    int totalQuality = 0;

    int countHots = 0;
    for (var stat in cardStatList) {
      totalQuality += stat.quality;

      if (stat.quality > hotCardQualityLimit) {
        countHots ++;
      }
    }

    if (countHots < hotCountLimit) {
      final stat = await _prepareNewCard();
      if (stat != null) return await _getCardIdFromStatID( stat.id );
    }

    if (cardStatList.isEmpty) return null;

    final selQuality = _random.nextInt(totalQuality + 1);

    int curQuality = 0;
    int selIndex = 0;
    for (int i = 0; i < cardStatList.length; i++){
      curQuality += cardStatList[i].quality;
      if (curQuality > selQuality) {
        selIndex = i;
        break;
      }
    }

    return await _getCardIdFromStatID( cardStatList[selIndex].id );
  }

  /// Регистрация результата тестирования по карточке
  Future<void> registerResult(int jsonFileID, String cardID, bool resultOk) async {
    final rows = await db.query(TabCardStat.tabName,
      where     : '${TabCardStat.kJsonFileID} = ? and ${TabCardStat.kCardID} = ?',
      whereArgs : [jsonFileID, cardID],
    );

    final row = Map<String, Object?>.from(rows[0]) ;
    
    final curDay = dateToInt(DateTime.now());

    row[TabCardStat.kLastTestDate] = curDay;

    final testsCount = row[TabCardStat.kTestsCount] as int;
    row[TabCardStat.kTestsCount] = testsCount + 1;

    final jsonStr = row[TabCardStat.kJson] as String?;
    final dayResultList = TabCardStat.dayResultsFromJson(jsonStr??'');

    DayResult? dayResult;
    dayResult = dayResultList.firstWhereOrNull((dayResult) => dayResult.day == curDay);
    if (dayResult == null) {
      dayResult = DayResult(day: curDay);
      dayResultList.add(dayResult);
    }

    dayResult.addResult(resultOk);

    while (dayResultList.length > hotDayCount) {
      dayResultList.removeAt(0);
    }
    
    double f = 0;
    for (var dayResult in dayResultList) {
      f += ( minimalQuality * dayResult.countOk ) / dayResult.countTotal;
    }
    
   var quality = minimalQuality - f ~/ dayResultList.length;
   if (quality == 0) quality = 1;

    row[TabCardStat.kQuality] = quality;

    row[TabCardStat.kJson] = TabCardStat.dayResultsToJson(dayResultList);

    row[TabCardStat.kQualityFromDate] = dayResultList[0].day;

    final rowID = row[TabCardStat.kID] as int;
    row.remove(TabCardStat.kID);
    
    await db.update(TabCardStat.tabName, row,
      where: '${TabCardStat.kID} = ?',
      whereArgs: [rowID]
    );

    final cardStat = cardStatList.firstWhere((cardStat) => cardStat.id == rowID);
    cardStat.quality = quality;
  }

  /// Вибирает и подготавливает новую карточку к началу изучению
  Future<_CardStat?> _prepareNewCard() async {
    List<Map<String, Object?>> rows;

    // отбираем связи в которых ParentCard уже изуена, а Card ещё не начинала изучаться
    rows = await db.rawQuery('SELECT '
        '${TabCardLink.tabName}.${TabCardLink.kJsonFileID}, '
        '${TabCardLink.tabName}.${TabCardLink.kCardID} '
        'FROM ${TabCardLink.tabName} '
        'JOIN ${TabCardStat.tabName} '
        '  ON ${TabCardStat.tabName}.${TabCardStat.kJsonFileID} = ${TabCardLink.tabName}.${TabCardLink.kJsonFileID} '
        ' AND ${TabCardStat.tabName}.${TabCardStat.kCardID}     = ${TabCardLink.tabName}.${TabCardLink.kParentCardID} '
        'WHERE ${TabCardStat.tabName}.${TabCardStat.kQuality} <= ? '
        '  AND NOT EXISTS ( '
        '    SELECT 1 '
        '      FROM ${TabCardStat.tabName} as sub '
        '     WHERE sub.${TabCardStat.kJsonFileID} = ${TabCardLink.tabName}.${TabCardLink.kJsonFileID} '
        '       AND sub.${TabCardStat.kCardID}     = ${TabCardLink.tabName}.${TabCardLink.kCardID} '
        '  ) ',
        [hotCardQualityLimit]
    );

    if (rows.isEmpty) { // Выбираем карточки которые ещё не изучаются и у которых нет связей с выше стоящими
      rows = await db.rawQuery('SELECT '
          '${TabCardHead.tabName}.${TabCardHead.kJsonFileID}, '
          '${TabCardHead.tabName}.${TabCardHead.kCardID} '
          'FROM ${TabCardHead.tabName} '
          'WHERE NOT EXISTS ( '
          '    SELECT 1 '
          '      FROM ${TabCardStat.tabName} '
          '     WHERE ${TabCardStat.tabName}.${TabCardStat.kJsonFileID} = ${TabCardHead.tabName}.${TabCardHead.kJsonFileID} '
          '       AND ${TabCardStat.tabName}.${TabCardStat.kCardID}     = ${TabCardHead.tabName}.${TabCardHead.kCardID} '
          '  ) '
          '  AND NOT EXISTS ( '
          '    SELECT 1 '
          '      FROM ${TabCardLink.tabName} '
          '     WHERE ${TabCardLink.tabName}.${TabCardLink.kJsonFileID} = ${TabCardHead.tabName}.${TabCardHead.kJsonFileID} '
          '       AND ${TabCardLink.tabName}.${TabCardLink.kCardID}     = ${TabCardHead.tabName}.${TabCardHead.kCardID} '
          '  ) '
      );
    }

    if (rows.isEmpty) return null;

    int rndIndex = 0;
    if (rows.length > 1) rndIndex = _random.nextInt(rows.length);

    final row = rows[rndIndex];

    final jsonFileID = row[TabCardLink.kJsonFileID] as int;
    final cardID     = row[TabCardLink.kCardID]     as String;

    final cardStat = await _initStatData(jsonFileID : jsonFileID, cardID: cardID);
    return cardStat;
  }

  Future<_CardStat> _initStatData({ required int jsonFileID, required String cardID }) async {
    final curDay = dateToInt(DateTime.now());

    Map<String, Object> row = {
      TabCardStat.kJsonFileID : jsonFileID,
      TabCardStat.kCardID          : cardID,
      TabCardStat.kQuality         : minimalQuality,
      TabCardStat.kQualityFromDate : curDay,
      TabCardStat.kStartDate       : curDay,
      TabCardStat.kTestsCount      : 0,
      TabCardStat.kJson            : '',
    };

    final id = await db.insert(TabCardStat.tabName, row);

    final cardStat = _CardStat(id: id, quality: minimalQuality);
    cardStatList.add(cardStat);

    return cardStat;
  }

  Future<Map<String, dynamic>?> getStatData({ required int jsonFileID, required String cardID }) async {
    final statData = await TabCardStat.getRow(jsonFileID: jsonFileID, cardID: cardID);
    if (statData != null) return statData;

    await _initStatData(jsonFileID : jsonFileID, cardID: cardID);
    final newStatData = await TabCardStat.getRow(jsonFileID: jsonFileID, cardID: cardID);
    return newStatData;
  }
}