import 'dart:convert';
import 'dart:io';
import 'package:flutter_archive/flutter_archive.dart';
import 'package:path/path.dart' as path_util;

import 'db.dart';

enum DecardFileType {
  json,
  zip,
  notDecardFile
}

DecardFileType getDecardFileType(String fileName){
  final fileExt = path_util.extension(fileName).toLowerCase();
  if (fileExt == '.decardj') return DecardFileType.json;
  if (fileExt == '.decardz') return DecardFileType.zip;
  return DecardFileType.notDecardFile;
}

class DataLoader {
  static String _selfDir = '';
  static int _dirIndex = 0;
  static final errorList = <String>[];

  static int _lastSourceFileID = 0;


  static const String _subDirPrefix    = 'j'; // прификс для имени подкаталога

  static const String _kID             = 'id';
  static const String _kCardStyleList  = 'cardStyleList';
  static const String _kCardList       = 'cardList';
  static const String _kCardBodyList   = 'bodyList';
  static const String _kCardLinkList   = 'linkList';
  static const String _kCardLinkCardID = 'cardID';

  /// Сканирует список каталогов и отбирает файлы с расширениями: '.decardz', '.decardj'
  /// файлы '.decardz' распаковываются в подкаталоги, префикс для подкаталогов [_subDirPrefix]
  /// данные '.decardj' сохраняются в БД
  /// выполняется контроль версий по сравнению с тем что было загружено ранее в БД
  static Future<void> refreshDB({ required List<String> dirForScanList, required String selfDir }) async {
    DataLoader._selfDir = selfDir;
    errorList.clear();

    for (var dir in dirForScanList) {
      _scanDir(dir, regFiles : true);
    }
  }

  static Future<bool> _scanDir(String dir, {bool regFiles = false}) async {
    bool result = false;

    final fileList = Directory(dir).listSync( recursive: true);
    for (var object in fileList) { 
      if (object is File){
        final File file = object;
        final fileType = getDecardFileType(file.path);

        if (fileType == DecardFileType.zip) {
          if (await _checkFileIsNoRegistered(file)) {
            if (regFiles) await _registerFile(file);
            if (await _processZip(file)) {
              result = true;
            }
          }
        }

        if (fileType == DecardFileType.json) {
          if (await _checkFileIsNoRegistered(file)) {
            if (regFiles) await _registerFile(file);
            if (await _processJson(file)) {
              result = true;
            }
          }
        }

      }
    }

    return result;
  }

  static Future<void> _registerFile(File file) async {
    _lastSourceFileID = await TabSourceFile.registerFile(file);
  }

  static Future<bool> _checkFileIsNoRegistered(File file) async {
    return ! await TabSourceFile.checkFileRegistered(file);
  }

  static Future<bool> _processZip(File zipFile) async {
    bool result = false;

    Directory dir;
    do {
      _dirIndex ++;
      dir = Directory(path_util.join(_selfDir, '$_subDirPrefix$_dirIndex' ));
    } while (await dir.exists());
    await dir.create();

    try {
      await ZipFile.extractToDirectory(zipFile: zipFile, destinationDir: dir);
      result = await _scanDir(dir.path);
      if (!result){
        dir.delete(recursive: true);
      }
    } catch (e) {
      errorList.add(e.toString());
    }

    return result;
  }

  static Future<bool> _processJson(File jsonFile) async {
    final fileData = await jsonFile.readAsString();
    final json = jsonDecode(fileData);

    final String guid = json[TabJsonFile.kGuid]??'';
    if (guid.isEmpty) {
      errorList.add('in file ${jsonFile.path} filed ${TabJsonFile.kGuid} not found');
      return false;
    }

    final int fileVersion = json[TabJsonFile.kVersion]??0;

    bool isNew = true;

    if (await TabJsonFile.getRowByGuid(guid)) {
      if (fileVersion <= TabJsonFile.version) return false;
      isNew = false;
      await _clearJsonFileID(TabJsonFile.jsonFileID);
    }

    TabJsonFile.setRow(_lastSourceFileID, path_util.dirname(jsonFile.path), path_util.basename(jsonFile.path), json);
    await TabJsonFile.save();

    final int jsonFileID = TabJsonFile.jsonFileID;

    final styleList = (json[_kCardStyleList]) as List;
    for (Map<String, dynamic> cardStyle in styleList) {
      await TabCardStyle.insertRow(
        jsonFileID  : jsonFileID,
        cardStyleID : cardStyle[_kID],
        jsonStr     : jsonEncode(cardStyle)
      );
    }

    final cardIdList = <String>[];

    final cardList = (json[_kCardList]) as List;
    for (Map<String, dynamic> card in cardList) {
      final String cardID = card[_kID];
      cardIdList.add(cardID);

      final bodyList = (card[_kCardBodyList]) as List;
      await _processCardBodyList(
        jsonFileID : jsonFileID,
        cardID     : cardID,
        bodyList   : bodyList,
      );

      if (card[_kCardLinkList] != null){
        final linkList = (card[_kCardLinkList]) as List;
        await _processCardLinkList(
          jsonFileID : jsonFileID,
          cardID     : cardID,
          linkList   : linkList,
        );
      }

      await TabCardHead.insertRow(
          jsonFileID : jsonFileID,
          cardID     : cardID,
          title      : card[TabCardHead.kTitle],
          bodyCount  : bodyList.length
      );

    }

    if (!isNew){
      await TabCardStat.removeOldCard(jsonFileID, cardIdList);
    }

    return true;
  }

  static Future<void> _processCardBodyList({ required int jsonFileID, required String cardID, required List bodyList }) async {
    int bodyNum = 0;
    for (var body in bodyList) {
      TabCardBody.insertRow(
        jsonFileID : jsonFileID,
        cardID     : cardID,
        bodyNum    : bodyNum,
        json       : jsonEncode(body)
      );
      bodyNum++;
    }
  }

  static Future<void> _processCardLinkList({ required int jsonFileID, required String cardID, required List linkList }) async {
    for (var link in linkList) {
      TabCardLink.insertRow(
        jsonFileID     : jsonFileID,
        cardID         : cardID,
        parentCardId   : link[_kCardLinkCardID],
        connectionType : link[TabCardLink.kConnectionType]
      );
    }
  }

  static Future<void> _clearJsonFileID(int jsonFileID) async {
    await TabCardStyle.deleteJsonFile(jsonFileID);
    await TabCardHead.deleteJsonFile(jsonFileID);
    await TabCardBody.deleteJsonFile(jsonFileID);
    await TabCardLink.deleteJsonFile(jsonFileID);
  }
}